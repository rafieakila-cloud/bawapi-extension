// Draw On Browser — klik ikon toolbar untuk toggle mode gambar di tab aktif
function toggleDraw(tabId) {
  browser.tabs.executeScript(tabId, { file: 'draw.js' }).catch(() => {});
}

browser.browserAction.onClicked.addListener(tab => toggleDraw(tab.id));

browser.commands.onCommand.addListener(command => {
  if (command === 'toggle-draw') {
    browser.tabs.query({ active: true, currentWindow: true }).then(tabs => {
      if (tabs[0]) toggleDraw(tabs[0].id);
    });
  }
});
