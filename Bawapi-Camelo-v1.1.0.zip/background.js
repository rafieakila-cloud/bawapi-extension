// Camelo — menghitung permintaan iklan/pelacak/analitik per tab + badge di toolbar
const camelo = {};

const AD_PATTERNS = [
  'googlesyndication', 'doubleclick', 'googleadservices', 'google-analytics',
  'googletagmanager', 'adservice', 'adnxs', 'adroll', 'criteo', 'taboola',
  'outbrain', 'moatads', 'amazon-adsystem', 'pubmatic', 'rubiconproject',
  'openx', 'casalemedia', 'smartadserver', 'adform', '/ads', '/adserver',
  'pagead', 'prebid'
];
const TRACKER_PATTERNS = [
  'facebook.net', 'connect.facebook', 'hotjar', 'scorecardresearch',
  'quantserve', 'newrelic', 'segment.com', 'segment.io', 'mixpanel',
  'amplitude', 'fullstory', 'mouseflow', 'track', 'pixel', 'beacon',
  'clarity.ms', 'heap', '/t.gif', 'telemetry'
];
const ANALYTICS_PATTERNS = [
  'google-analytics.com', 'analytics.google', 'googletagmanager.com/gtm',
  'statcounter', 'matomo', 'piwik', 'yandex.ru/metrika', 'baidu'
];

function categorize(url) {
  const u = url.toLowerCase();
  for (const p of ANALYTICS_PATTERNS) if (u.includes(p)) return 'analytics';
  for (const p of AD_PATTERNS) if (u.includes(p)) return 'ads';
  for (const p of TRACKER_PATTERNS) if (u.includes(p)) return 'trackers';
  return null;
}

function hostOf(url) {
  try { return new URL(url).hostname; } catch (e) { return url.slice(0, 60); }
}

browser.webRequest.onBeforeRequest.addListener(
  details => {
    if (details.tabId < 0) return;
    const cat = categorize(details.url);
    if (!cat) return;
    const s = (camelo[details.tabId] = camelo[details.tabId] || { ads: 0, trackers: 0, analytics: 0, items: [] });
    s[cat] += 1;
    s.items.unshift({ host: hostOf(details.url), cat });
    if (s.items.length > 12) s.items.pop();
    const total = s.ads + s.trackers + s.analytics;
    browser.browserAction.setBadgeBackgroundColor({ color: '#d32f2f', tabId: details.tabId });
    browser.browserAction.setBadgeText({ text: String(Math.min(total, 999)), tabId: details.tabId });
  },
  { urls: ['<all_urls>'] }
);

browser.tabs.onRemoved.addListener(tabId => { delete camelo[tabId]; });

browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    camelo[tabId] = { ads: 0, trackers: 0, analytics: 0, items: [] };
    browser.browserAction.setBadgeText({ text: '', tabId });
  }
});

browser.runtime.onMessage.addListener(msg => {
  if (!msg || !msg.type) return undefined;
  if (msg.type === 'camelo:get') {
    return Promise.resolve(camelo[msg.tabId] || { ads: 0, trackers: 0, analytics: 0, items: [] });
  }
  if (msg.type === 'camelo:reset') {
    camelo[msg.tabId] = { ads: 0, trackers: 0, analytics: 0, items: [] };
    browser.browserAction.setBadgeText({ text: '', tabId: msg.tabId });
    return Promise.resolve(true);
  }
  return undefined;
});
