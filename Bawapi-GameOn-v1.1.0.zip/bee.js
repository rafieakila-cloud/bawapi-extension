// Game On — Lebah Bawapi (SVG, bukan emoji)
// Panggilan pertama: lepas lebah. Panggilan berikutnya: panggil kembali.
(function () {
  if (window.__bawapiBee) {
    window.__bawapiBee.remove();
    delete window.__bawapiBee;
    return 'Lebah ditarik kembali ke sarang. Sampai jumpa!';
  }

  const beeSVG =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="72" height="72">' +
    '<ellipse cx="30" cy="26" rx="13" ry="10" fill="#fffdf5" fill-opacity=".85" stroke="#1a1a1a" stroke-width="4"/>' +
    '<ellipse cx="66" cy="24" rx="13" ry="10" fill="#fffdf5" fill-opacity=".85" stroke="#1a1a1a" stroke-width="4"/>' +
    '<ellipse cx="46" cy="56" rx="26" ry="19" fill="#fdd835" stroke="#1a1a1a" stroke-width="5"/>' +
    '<path d="M32 50h28M32 62h28" stroke="#1a1a1a" stroke-width="5"/>' +
    '<circle cx="32" cy="52" r="3.4" fill="#1a1a1a"/>' +
    '<path d="M72 52l14-5M72 58l14 0M72 64l14 5" stroke="#1a1a1a" stroke-width="4" stroke-linecap="round"/>' +
    '</svg>';

  const bee = document.createElement('div');
  bee.innerHTML = beeSVG;
  bee.title = 'Klik aku!';
  bee.style.cssText =
    'position:fixed;bottom:14px;left:0;z-index:2147483647;cursor:pointer;user-select:none;' +
    'filter:drop-shadow(0 3px 3px rgba(0,0,0,.3));transition:transform .15s;';
  document.documentElement.appendChild(bee);

  let x = -90;
  let dir = 1;
  let t = 0;
  let raf;
  const speed = 2.4;

  function tick() {
    t += 0.08;
    x += dir * speed;
    const max = window.innerWidth - 80;
    if (x > max) { x = max; dir = -1; }
    if (x < -90) { x = -90; dir = 1; }
    const bob = Math.sin(t) * 10;
    bee.style.left = x + 'px';
    bee.style.bottom = (14 + bob) + 'px';
    bee.style.transform = dir === 1 ? 'scaleX(1)' : 'scaleX(-1)';
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  function floatHoney(px, py) {
    const d = document.createElement('div');
    d.textContent = '+1 madu';
    d.style.cssText =
      'position:fixed;z-index:2147483647;left:' + px + 'px;top:' + (py - 30) + 'px;' +
      'font:700 18px Georgia,serif;color:#b45309;pointer-events:none;' +
      'transition:transform 1.2s,opacity 1.2s;opacity:1;';
    document.documentElement.appendChild(d);
    requestAnimationFrame(() => {
      d.style.transform = 'translateY(-60px)';
      d.style.opacity = '0';
    });
    setTimeout(() => d.remove(), 1300);
  }

  bee.addEventListener('click', e => {
    floatHoney(e.clientX, e.clientY);
    browser.storage.local.get('honeyScore').then(d => {
      browser.storage.local.set({ honeyScore: (d.honeyScore || 0) + 1 });
    });
  });

  window.__bawapiBee = {
    remove() {
      cancelAnimationFrame(raf);
      bee.remove();
    }
  };
  return 'Lebah dilepaskan! Klik lebahnya untuk memanen madu.';
})();
