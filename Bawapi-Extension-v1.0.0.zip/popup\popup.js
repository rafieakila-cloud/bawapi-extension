// Bawapi Extension — popup controller
const $ = sel => document.querySelector(sel);

const RANDOM_WEBS = [
  'https://en.wikipedia.org/wiki/Special:Random',
  'https://developer.mozilla.org/en-US/docs/Web/CSS',
  'https://www.kernel.org',
  'https://tldp.org/HOWTO/',
  'https://archlinux.org/docs/',
  'https://itsfoss.com',
  'https://www.linux.com',
  'https://www.tecmint.com',
  'https://www.howtoforge.com',
  'https://wiki.archlinux.org/title/Main_page',
  'https://wiki.gentoo.org',
  'https://linuxjourney.com',
  'https://www.geeksforgeeks.org',
  'https://stackoverflow.com/questions',
  'https://developer.mozilla.org/en-US/docs/Web/HTML',
  'https://css-tricks.com',
  'https://news.ycombinator.com',
  'https://www.sciencedaily.com',
  'https://www.nature.com',
  'https://www.britannica.com',
  'https://www.poetryfoundation.org',
  'https://gutenberg.org/ebooks/search/?sort_order=popular',
  'https://www.coursera.org',
  'https://www.khanacademy.org'
];

async function activeTab() {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function setStatus(el, text) {
  el.textContent = text;
  setTimeout(() => { if (el.textContent === text) el.textContent = ''; }, 4000);
}

// ---------- 1. Draw On Browser ----------
$('#btn-draw').addEventListener('click', async () => {
  try {
    const tab = await activeTab();
    const res = await browser.tabs.executeScript(tab.id, { file: 'content/draw.js' });
    $('#draw-status').textContent = (res && res[0]) || 'Selesai.';
  } catch (e) {
    $('#draw-status').textContent = 'Tidak bisa menggambar di halaman ini (halaman internal browser diblokir).';
  }
});

// ---------- 2. Notes On ----------
const notesEl = $('#notes');
const notesCount = $('#notes-count');
let notesTimer = null;

function refreshNotesCount() {
  notesCount.textContent = notesEl.value.length + ' karakter';
}
browser.storage.local.get('notes').then(d => {
  notesEl.value = d.notes || '';
  refreshNotesCount();
});
notesEl.addEventListener('input', () => {
  refreshNotesCount();
  clearTimeout(notesTimer);
  notesTimer = setTimeout(() => {
    browser.storage.local.set({ notes: notesEl.value });
  }, 300);
});
$('#notes-clear').addEventListener('click', () => {
  notesEl.value = '';
  refreshNotesCount();
  browser.storage.local.set({ notes: '' });
});

// ---------- 3. Information On ----------
async function dohLookup(host, type) {
  const url = 'https://cloudflare-dns.com/dns-query?name=' + encodeURIComponent(host) + '&type=' + type + '&accept=application/dns-json';
  const res = await fetch(url);
  const json = await res.json();
  return (json.Answer || []).filter(a => a.type === (type === 'A' ? 1 : 28)).map(a => a.data);
}

async function refreshInfo() {
  const tab = await activeTab();
  const url = tab && tab.url ? tab.url : '';
  $('#info-url').textContent = url || '(tidak ada URL)';
  let host = '', proto = '';
  try {
    const u = new URL(url);
    host = u.hostname;
    proto = u.protocol.replace(':', '').toUpperCase();
  } catch (e) { /* about:blank dll. */ }
  $('#info-host').textContent = host || '—';
  $('#info-proto').textContent = proto || '—';
  $('#info-ip').textContent = host ? 'mencari…' : '—';
  if (host) {
    try {
      const [a, aaaa] = await Promise.all([dohLookup(host, 'A'), dohLookup(host, 'AAAA')]);
      $('#info-ip').textContent = (a.concat(aaaa).join(', ')) || 'tidak ditemukan';
    } catch (e) {
      $('#info-ip').textContent = 'gagal (perlu koneksi internet)';
    }
  }
  try {
    const reply = await browser.runtime.sendMessage({ type: 'camelo:get', tabId: tab.id });
    $('#info-server').textContent = (reply.server && reply.server.server) || '—';
    $('#info-powered').textContent = (reply.server && reply.server.poweredBy) || '—';
  } catch (e) {
    $('#info-server').textContent = '—';
    $('#info-powered').textContent = '—';
  }
}
$('#info-refresh').addEventListener('click', refreshInfo);

// ---------- 4. Random Web ----------
$('#btn-random').addEventListener('click', () => {
  const pick = RANDOM_WEBS[Math.floor(Math.random() * RANDOM_WEBS.length)];
  browser.tabs.create({ url: pick });
});

// ---------- 5. Check Language Program ----------
$('#btn-detect').addEventListener('click', async () => {
  const out = $('#detect-result');
  out.textContent = 'Mendeteksi…';
  try {
    const tab = await activeTab();
    const res = await browser.tabs.executeScript(tab.id, { file: 'content/techcheck.js' });
    const r = res && res[0];
    if (r) {
      out.textContent =
        (r.generator ? 'Generator: ' + r.generator + '\n\n' : '') + r.summary;
    } else {
      out.textContent = 'Tidak ada hasil.';
    }
  } catch (e) {
    out.textContent = 'Tidak bisa menganalisis halaman ini (halaman internal browser diblokir).';
  }
});

// ---------- 6. APK Guard ----------
const apkToggle = $('#apk-guard');
const apkLabel = $('#apk-guard-label');
function apkLabelText(on) {
  apkLabel.textContent = 'APK Guard: ' + (on ? 'AKTIF 🛡️' : 'MATI');
}
browser.storage.local.get('apkGuard').then(d => {
  apkToggle.checked = !!d.apkGuard;
  apkLabelText(apkToggle.checked);
});
apkToggle.addEventListener('change', () => {
  const on = apkToggle.checked;
  apkLabelText(on);
  browser.storage.local.set({ apkGuard: on });
});

// ---------- 7. Camelo ----------
const cameloItems = $('#camelo-items');
async function refreshCamelo() {
  try {
    const tab = await activeTab();
    const reply = await browser.runtime.sendMessage({ type: 'camelo:get', tabId: tab.id });
    const s = reply.stats || { ads: 0, trackers: 0, analytics: 0, items: [] };
    $('#camelo-ads').textContent = s.ads;
    $('#camelo-trackers').textContent = s.trackers;
    $('#camelo-analytics').textContent = s.analytics;
    cameloItems.innerHTML = '';
    for (const item of s.items) {
      const li = document.createElement('li');
      const b = document.createElement('b');
      b.textContent = item.cat === 'ads' ? 'Iklan' : item.cat === 'analytics' ? 'Analitik' : 'Pelacak';
      li.appendChild(b);
      li.appendChild(document.createTextNode(' — ' + item.host));
      cameloItems.appendChild(li);
    }
  } catch (e) { /* abaikan */ }
}
$('#camelo-reset').addEventListener('click', async () => {
  const tab = await activeTab();
  await browser.runtime.sendMessage({ type: 'camelo:reset', tabId: tab.id });
  refreshCamelo();
});

// ---------- 8. Game On ----------
const honeyEl = $('#honey-score');
function refreshHoney() {
  browser.storage.local.get('honeyScore').then(d => {
    honeyEl.textContent = d.honeyScore || 0;
  });
}
$('#btn-bee').addEventListener('click', async () => {
  try {
    const tab = await activeTab();
    await browser.tabs.executeScript(tab.id, { file: 'content/bee.js' });
  } catch (e) {
    $('#honey-score').textContent = '!';
  }
  refreshHoney();
});

// ---------- 9. Search Omni ----------
const omniInput = $('#omni-input');
function omniUrl() {
  const q = omniInput.value.trim();
  return q ? 'https://duckduckgo.com/?q=' + encodeURIComponent(q) : null;
}
$('#omni-form').addEventListener('submit', e => {
  e.preventDefault();
  const url = omniUrl();
  if (url) browser.tabs.create({ url });
});
$('#omni-tab').addEventListener('click', () => {
  const url = omniUrl();
  if (url) browser.tabs.create({ url });
});
$('#omni-window').addEventListener('click', () => {
  const url = omniUrl();
  if (url) browser.windows.create({ url, type: 'popup', width: 900, height: 620 });
});

// ---------- 10. Kuda AI Ask! ----------
const kudaChat = $('#kuda-chat');
const kudaInput = $('#kuda-input');
const kudaKey = $('#kuda-key');
const kudaModel = $('#kuda-model');
const chatHistory = [];

browser.storage.local.get(['openrouterKey', 'openrouterModel']).then(d => {
  kudaKey.value = d.openrouterKey || '';
  kudaModel.value = d.openrouterModel || 'openai/gpt-4o-mini';
});
$('#kuda-save').addEventListener('click', () => {
  browser.storage.local.set({
    openrouterKey: kudaKey.value.trim(),
    openrouterModel: kudaModel.value.trim() || 'openai/gpt-4o-mini'
  });
  appendChat('ai', 'Pengaturan tersimpan. ✔');
});

function appendChat(role, text) {
  const div = document.createElement('div');
  div.className = role === 'user' ? 'msg-user' : 'msg-ai';
  div.textContent = (role === 'user' ? 'Kamu: ' : 'Kuda AI: ') + text;
  kudaChat.appendChild(div);
  kudaChat.scrollTop = kudaChat.scrollHeight;
  return div;
}

$('#kuda-form').addEventListener('submit', async e => {
  e.preventDefault();
  const question = kudaInput.value.trim();
  if (!question) return;
  const key = kudaKey.value.trim();
  const model = kudaModel.value.trim() || 'openai/gpt-4o-mini';
  if (!key) {
    appendChat('ai', 'Isi API key OpenRouter dulu, lalu klik "Simpan Pengaturan".');
    return;
  }
  kudaInput.value = '';
  appendChat('user', question);
  chatHistory.push({ role: 'user', content: question });
  if (chatHistory.length > 20) chatHistory.splice(0, chatHistory.length - 20);
  const thinking = appendChat('ai', 'Sedang berpikir…');
  try {
    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + key,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://github.com/rafieakila-cloud',
        'X-Title': 'Bawapi Extension — Kuda AI Ask!'
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: 'Kamu adalah Kuda AI, asisten berbahasa Indonesia yang ramah, ringkas, dan membantu.' },
          ...chatHistory
        ]
      })
    });
    const json = await res.json();
    const answer = (json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content)
      || (json.error && (json.error.message || JSON.stringify(json.error)))
      || 'Respons tidak dikenal.';
    thinking.textContent = 'Kuda AI: ' + answer;
    chatHistory.push({ role: 'assistant', content: answer });
  } catch (err) {
    thinking.textContent = 'Kuda AI: Gagal menghubungi OpenRouter — ' + err.message;
  }
  kudaChat.scrollTop = kudaChat.scrollHeight;
});

// ---------- init ----------
refreshInfo();
refreshCamelo();
refreshHoney();
