// Bawapi Extension — Draw On Browser
// Disuntikkan lewat tabs.executeScript setiap kali dipanggil.
// Panggilan pertama: aktifkan mode gambar. Panggilan berikutnya: matikan.
(function () {
  if (window.__bawapiDraw) {
    const on = window.__bawapiDraw.toggle();
    return on ? 'Mode gambar: AKTIF' : 'Mode gambar: MATI';
  }

  const Z = 2147483647;
  const canvas = document.createElement('canvas');
  canvas.id = 'bawapi-draw-canvas';
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.cssText =
    'position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:' + Z + ';' +
    'pointer-events:none;cursor:crosshair;touch-action:none;';
  document.documentElement.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  function resize() {
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx.putImageData(img, 0, 0);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }
  window.addEventListener('resize', resize);

  // Toolbar mengambang
  const bar = document.createElement('div');
  bar.id = 'bawapi-draw-toolbar';
  bar.style.cssText =
    'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:' + (Z + 1) + ';' +
    'display:flex;align-items:center;gap:8px;background:#fff;border:2px solid #1a1a1a;' +
    'border-radius:999px;padding:6px 12px;box-shadow:0 4px 14px rgba(0,0,0,.25);' +
    'font:13px system-ui,sans-serif;';

  const colors = ['#e53935', '#1e88e5', '#43a047', '#fdd835', '#1a1a1a', '#fb8c00'];
  let color = colors[0];
  let width = 4;

  function styleBtn(b) {
    b.style.cssText = 'width:26px;height:26px;border-radius:50%;border:2px solid #1a1a1a;cursor:pointer;padding:0;';
    return b;
  }
  colors.forEach(c => {
    const b = document.createElement('button');
    styleBtn(b).style.background = c;
    b.title = 'Warna ' + c;
    b.addEventListener('click', () => { color = c; });
    bar.appendChild(b);
  });

  const size = document.createElement('input');
  size.type = 'range';
  size.min = '1'; size.max = '20'; size.value = String(width);
  size.title = 'Ketebalan garis';
  size.addEventListener('input', () => { width = Number(size.value); });
  bar.appendChild(size);

  const clear = document.createElement('button');
  clear.textContent = 'Bersihkan';
  clear.style.cssText = 'border:2px solid #1a1a1a;background:#fff;border-radius:8px;padding:4px 10px;cursor:pointer;font-weight:600;';
  clear.addEventListener('click', () => ctx.clearRect(0, 0, canvas.width, canvas.height));
  bar.appendChild(clear);

  const exit = document.createElement('button');
  exit.textContent = 'Selesai';
  exit.style.cssText = 'border:2px solid #1a1a1a;background:#f5a623;border-radius:8px;padding:4px 12px;cursor:pointer;font-weight:700;';
  exit.addEventListener('click', () => api.toggle());
  bar.appendChild(exit);

  document.documentElement.appendChild(bar);

  // Coretan kursor
  let drawing = false;
  let last = null;
  function pos(e) {
    return { x: e.clientX, y: e.clientY };
  }
  canvas.addEventListener('pointerdown', e => {
    drawing = true;
    last = pos(e);
    canvas.setPointerCapture(e.pointerId);
    ctx.beginPath();
    ctx.arc(last.x, last.y, width / 2, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
  });
  canvas.addEventListener('pointermove', e => {
    if (!drawing) return;
    const p = pos(e);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(last.x, last.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last = p;
  });
  const stop = () => { drawing = false; };
  canvas.addEventListener('pointerup', stop);
  canvas.addEventListener('pointercancel', stop);

  const state = { active: true };
  function apply() {
    canvas.style.pointerEvents = state.active ? 'auto' : 'none';
    bar.style.display = state.active ? 'flex' : 'none';
  }
  apply();

  function onKey(e) { if (e.key === 'Escape' && state.active) api.toggle(); }
  document.addEventListener('keydown', onKey, true);

  const api = {
    toggle() {
      state.active = !state.active;
      apply();
      return state.active;
    }
  };
  window.__bawapiDraw = api;
  return 'Mode gambar: AKTIF — seret mouse untuk menggambar, Esc untuk selesai';
})();
