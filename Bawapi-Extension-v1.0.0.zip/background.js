// Bawapi Extension — background script
// Menghitung permintaan jaringan pihak ketiga yang mirip iklan/pelacak (Camelo)
// dan menyimpan info header respons situs (untuk fitur Check Language / Information On).

const camelo = {}; // tabId -> { ads: 0, trackers: 0, analytics: 0, items: [] }
const serverInfo = {}; // tabId -> { server, poweredBy }

const AD_PATTERNS = [
  'googlesyndication', 'doubleclick', 'googleadservices', 'google-analytics',
  'googletagmanager', 'adservice', 'adnxs', 'adroll', 'criteo', 'taboola',
  'outbrain', 'moatads', 'amazon-adsystem', 'pubmatic', 'rubiconproject',
  'openx', 'casalemedia', 'smartadserver', 'adform', '/ads', '/adserver',
  'pagead', 'prebid'
];
const TRACKER_PATTERNS = [
  'facebook.net', 'connect.facebook', 'hotjar', 'scorecardresearch',
  'quantserve', 'newrelic', 'segment.com', 'segment.io', 'mixpanel',
  'amplitude', 'fullstory', 'mouseflow', 'track', 'pixel', 'beacon',
  'clarity.ms', 'heap', '/t.gif', 'telemetry'
];
const ANALYTICS_PATTERNS = [
  'google-analytics.com', 'analytics.google', 'googletagmanager.com/gtm',
  'statcounter', 'matomo', 'piwik', 'yandex.ru/metrika', 'baidu'
];

function categorize(url) {
  const u = url.toLowerCase();
  for (const p of ANALYTICS_PATTERNS) if (u.includes(p)) return 'analytics';
  for (const p of AD_PATTERNS) if (u.includes(p)) return 'ads';
  for (const p of TRACKER_PATTERNS) if (u.includes(p)) return 'trackers';
  return null;
}

function hostOf(url) {
  try { return new URL(url).hostname; } catch (e) { return url.slice(0, 60); }
}

browser.webRequest.onBeforeRequest.addListener(
  details => {
    if (details.tabId < 0) return;
    const cat = categorize(details.url);
    if (!cat) return;
    const s = (camelo[details.tabId] = camelo[details.tabId] || { ads: 0, trackers: 0, analytics: 0, items: [] });
    s[cat] += 1;
    const host = hostOf(details.url);
    s.items.unshift({ host, cat });
    if (s.items.length > 12) s.items.pop();
    const total = s.ads + s.trackers + s.analytics;
    browser.browserAction.setBadgeBackgroundColor({ color: '#d32f2f', tabId: details.tabId });
    browser.browserAction.setBadgeText({ text: String(Math.min(total, 999)), tabId: details.tabId });
  },
  { urls: ['<all_urls>'] }
);

browser.webRequest.onHeadersReceived.addListener(
  details => {
    if (details.type !== 'main_frame' || !details.responseHeaders) return;
    const headers = {};
    for (const h of details.responseHeaders) headers[h.name.toLowerCase()] = h.value;
    serverInfo[details.tabId] = {
      server: headers['server'] || '',
      poweredBy: headers['x-powered-by'] || '',
      via: headers['via'] || '',
      contentType: headers['content-type'] || ''
    };
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

browser.tabs.onRemoved.addListener(tabId => {
  delete camelo[tabId];
  delete serverInfo[tabId];
});

browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    camelo[tabId] = { ads: 0, trackers: 0, analytics: 0, items: [] };
    browser.browserAction.setBadgeText({ text: '', tabId });
  }
});

browser.runtime.onMessage.addListener(msg => {
  if (!msg || !msg.type) return undefined;
  if (msg.type === 'camelo:get') {
    const s = camelo[msg.tabId] || { ads: 0, trackers: 0, analytics: 0, items: [] };
    return Promise.resolve({ stats: s, server: serverInfo[msg.tabId] || null });
  }
  if (msg.type === 'camelo:reset') {
    camelo[msg.tabId] = { ads: 0, trackers: 0, analytics: 0, items: [] };
    browser.browserAction.setBadgeText({ text: '', tabId: msg.tabId });
    return Promise.resolve(true);
  }
  return undefined;
});

// Shortcut keyboard: Ctrl+Shift+D -> toggle mode gambar di tab aktif
browser.commands.onCommand.addListener(command => {
  if (command === 'toggle-draw') {
    browser.tabs.query({ active: true, currentWindow: true }).then(tabs => {
      if (tabs[0]) browser.tabs.executeScript(tabs[0].id, { file: 'content/draw.js' });
    });
  } else if (command === 'open-panel') {
    // _execute_browser_action digantikan oleh perintah eksplisit bila perlu
    browser.tabs.query({ active: true, currentWindow: true }).then(() => {});
  }
});
