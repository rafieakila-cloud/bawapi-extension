// Bawapi Extension — Game On: Lebah Bebas
// Disuntikkan lewat tabs.executeScript. Panggilan pertama: lepas lebah. Kedua: panggil kembali.
(function () {
  if (window.__bawapiBee) {
    window.__bawapiBee.remove();
    delete window.__bawapiBee;
    return 'Lebah ditarik kembali ke sarang. Sampai jumpa! 🐝';
  }

  const bee = document.createElement('div');
  bee.textContent = '🐝';
  bee.title = 'Klik aku!';
  bee.style.cssText =
    'position:fixed;bottom:14px;left:0;z-index:2147483647;font-size:56px;' +
    'cursor:pointer;user-select:none;filter:drop-shadow(0 3px 3px rgba(0,0,0,.3));' +
    'transition:transform .15s;';
  document.documentElement.appendChild(bee);

  let x = -80;
  let dir = 1;
  let t = 0;
  let raf;
  const speed = 2.4;

  function tick() {
    t += 0.08;
    x += dir * speed;
    const max = window.innerWidth - 60;
    if (x > max) { x = max; dir = -1; }
    if (x < -80) { x = -80; dir = 1; }
    const bob = Math.sin(t) * 10;
    bee.style.left = x + 'px';
    bee.style.bottom = (14 + bob) + 'px';
    bee.style.transform = dir === 1 ? 'scaleX(1)' : 'scaleX(-1)';
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  function floatHoney(px, py) {
    const d = document.createElement('div');
    d.textContent = '🍯 +1';
    d.style.cssText =
      'position:fixed;z-index:2147483647;left:' + px + 'px;top:' + (py - 30) + 'px;' +
      'font:700 18px system-ui,sans-serif;color:#b45309;pointer-events:none;' +
      'transition:transform 1.2s,opacity 1.2s;opacity:1;';
    document.documentElement.appendChild(d);
    requestAnimationFrame(() => {
      d.style.transform = 'translateY(-60px)';
      d.style.opacity = '0';
    });
    setTimeout(() => d.remove(), 1300);
  }

  bee.addEventListener('click', e => {
    floatHoney(e.clientX, e.clientY);
    bee.style.transform += ' scale(1.4)';
    setTimeout(() => { bee.style.transform = bee.style.transform.replace(' scale(1.4)', ''); }, 150);
    browser.storage.local.get('honeyScore').then(d => {
      browser.storage.local.set({ honeyScore: (d.honeyScore || 0) + 1 });
    });
  });

  window.__bawapiBee = {
    remove() {
      cancelAnimationFrame(raf);
      bee.remove();
    }
  };
  return 'Lebah dilepaskan! 🐝 Klik lebahnya untuk memanen madu.';
})();
