# Bawapi Extension 🐝

**Gratis** — semua perkakas browser dalam satu tombol toolbar. Extension untuk Firefox.

## Fitur

| Fitur | Deskripsi |
|---|---|
| 🖌️ **Draw On Browser** | Gambar bebas di atas halaman web mana pun. Shortcut `Ctrl+Shift+D`, keluar dengan `Esc`. |
| 📝 **Notes On** | Catatan sederhana yang tersimpan otomatis di browser. |
| ℹ️ **Information On** | Menampilkan URL, domain, protokol, IP (via DNS over HTTPS), serta header `Server` dan `X-Powered-By`. |
| 🎲 **Random Web** | Tombol dadu yang membuka web pengetahuan/Linux acak (bukan judi/pornografi). |
| 🔎 **Check Language Program** | Menebak bahasa & teknologi pemrograman di balik sebuah web (WordPress, React, Next.js, dsb). |
| 🛡️ **APK Guard** | Memblokir link download `.apk` di halaman (berguna untuk parental control). |
| 🕵️ **Camelo** | Menghitung iklan, pelacak, dan skrip analitik yang dimuat sebuah web (dengan badge angka di ikon). |
| 🐝 **Game On** | Lepaskan lebah yang berjalan bebas di halaman; klik lebahnya untuk memanen madu 🍯. Juga berisi rekomendasi downloader game resmi. |
| 🔍 **Search Omni** | Pencarian di tab baru atau di **jendela virtual** (popup terpisah). |
| 🐎 **Kuda AI Ask!** | Chat AI dengan API key OpenRouter milikmu sendiri (tersimpan lokal, tidak dikirim ke mana pun selain OpenRouter). |

## Cara Install (sementara, untuk dicoba)

1. Download `Bawapi-Extension-v1.0.0.zip` dan **ekstrak**.
2. Buka Firefox → ketik `about:debugging` di address bar.
3. Klik **This Firefox** → **Load Temporary Add-on...**
4. Pilih file `manifest.json` di dalam folder hasil ekstrak.
5. Ikon lebah 🐝 muncul di toolbar. Klik untuk membuka panel semua fitur.

> **Catatan:** Extension sementara hilang saat Firefox ditutup. Agar permanen, extension harus **ditandatangani** oleh Mozilla (daftar gratis di https://addons.mozilla.org sebagai *unlisted/self-distributed*, lalu install file `.xpi` hasil tanda tangan).

## Shortcut

- `Ctrl+Shift+D` — aktif/matikan mode gambar di tab aktif
- `Ctrl+Shift+U` — (cadangan) buka panel

## Struktur

```
BawapiExtension/
├── manifest.json        # Manifest V2 (Firefox)
├── background.js        # Camelo counter + shortcut keyboard
├── content/
│   ├── guard.js         # APK Guard
│   ├── draw.js          # Draw On Browser (canvas overlay)
│   ├── bee.js           # Game On: lebah berjalan
│   └── techcheck.js     # Deteksi bahasa pemrograman
├── popup/
│   ├── popup.html       # Panel utama semua fitur
│   ├── popup.css        # UI putih simpel
│   └── popup.js         # Logika semua fitur
└── icons/               # Ikon SVG (lebah)
```

## Batasan

- Deteksi bahasa pemrograman bersifat **heuristik** (tebakan dari tanda-tanda di halaman), bukan kepastian.
- Kuda AI memerlukan API key OpenRouter sendiri — dapat dibuat di https://openrouter.ai.
- IP address situs di-resolve lewat Cloudflare DoH; situs dengan CDN akan menampilkan IP CDN.
