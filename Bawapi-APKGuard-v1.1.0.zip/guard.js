// Bawapi Extension — APK Guard
// Memblokir klik pada link download .apk bila pengguna mengaktifkan APK Guard.
(async () => {
  let enabled = false;
  try {
    const data = await browser.storage.local.get('apkGuard');
    enabled = !!data.apkGuard;
  } catch (e) { /* storage tidak tersedia */ }
  if (!enabled) return;

  function banner(text) {
    const div = document.createElement('div');
    div.textContent = text;
    div.setAttribute('style',
      'position:fixed;z-index:2147483647;bottom:24px;left:50%;transform:translateX(-50%);' +
      'background:#1a1a1a;color:#fff;padding:12px 18px;border-radius:8px;' +
      'font:14px/1.4 system-ui,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.35);' +
      'max-width:80vw;text-align:center;opacity:1;transition:opacity .4s');
    document.documentElement.appendChild(div);
    setTimeout(() => { div.style.opacity = '0'; }, 3500);
    setTimeout(() => div.remove(), 4000);
  }

  document.addEventListener('click', event => {
    const a = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!a) return;
    const href = a.href || '';
    if (/\.apk(\?|#|$|\/)/i.test(href) || /\.apk\b/i.test(href)) {
      event.preventDefault();
      event.stopPropagation();
      banner('APK Guard: download APK diblokir. Matikan di ikon APK Guard.');
    }
  }, true);
})();
