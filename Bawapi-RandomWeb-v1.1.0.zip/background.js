// Random Web — buka satu web pengetahuan acak
const RANDOM_WEBS = [
  'https://en.wikipedia.org/wiki/Special:Random',
  'https://developer.mozilla.org/en-US/docs/Web/CSS',
  'https://developer.mozilla.org/en-US/docs/Web/HTML',
  'https://www.kernel.org',
  'https://tldp.org/HOWTO/',
  'https://archlinux.org/docs/',
  'https://itsfoss.com',
  'https://www.linux.com',
  'https://www.tecmint.com',
  'https://www.howtoforge.com',
  'https://wiki.archlinux.org/title/Main_page',
  'https://wiki.gentoo.org',
  'https://linuxjourney.com',
  'https://www.geeksforgeeks.org',
  'https://stackoverflow.com/questions',
  'https://css-tricks.com',
  'https://news.ycombinator.com',
  'https://www.sciencedaily.com',
  'https://www.nature.com',
  'https://www.britannica.com',
  'https://www.poetryfoundation.org',
  'https://gutenberg.org/ebooks/search/?sort_order=popular',
  'https://www.coursera.org',
  'https://www.khanacademy.org'
];

browser.browserAction.onClicked.addListener(() => {
  const pick = RANDOM_WEBS[Math.floor(Math.random() * RANDOM_WEBS.length)];
  browser.tabs.create({ url: pick });
});
