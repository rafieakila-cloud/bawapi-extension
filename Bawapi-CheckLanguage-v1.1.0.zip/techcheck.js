// Bawapi Extension — Check Language Program
// Menebak bahasa/teknologi pemrograman di balik situs dari meta generator,
// skrip/link yang dimuat, dan atribut DOM. Nilai kembali berupa objek ringkasan.
(function () {
  const findings = new Map(); // nama -> [role, tebakan bahasa]
  const add = (name, tech, lang) => { if (!findings.has(name)) findings.set(name, { tech, lang }); };

  const srcs = [];
  document.querySelectorAll('script[src]').forEach(s => srcs.push(s.src));
  document.querySelectorAll('link[href]').forEach(l => srcs.push(l.href));
  document.querySelectorAll('img[src]').forEach(i => srcs.push(i.src));
  const hay = (srcs.join('\n') + '\n' + document.documentElement.outerHTML.slice(0, 300000)).toLowerCase();

  const generator =
    (document.querySelector('meta[name="generator"]') || {}).content ||
    (document.querySelector('meta[property="og:site_name"]') || {}).content ||
    '';
  const gen = generator.toLowerCase();

  if (gen.includes('wordpress')) add('WordPress', 'WordPress', 'PHP');
  if (gen.includes('joomla')) add('Joomla', 'Joomla', 'PHP');
  if (gen.includes('drupal')) add('Drupal', 'Drupal', 'PHP');
  if (gen.includes('wix')) add('Wix', 'Wix', 'JavaScript (Velo)');
  if (gen.includes('squarespace')) add('Squarespace', 'Squarespace', 'JavaScript');
  if (gen.includes('django')) add('Django', 'Django', 'Python');
  if (gen.includes('laravel')) add('Laravel', 'Laravel', 'PHP');
  if (gen.includes('hugo')) add('Hugo', 'Hugo', 'Go (template)');
  if (gen.includes('jekyll')) add('Jekyll', 'Jekyll', 'Ruby');
  if (gen.includes('gatsby')) add('Gatsby', 'Gatsby', 'JavaScript (React)');
  if (gen.includes('astro')) add('Astro', 'Astro', 'JavaScript');

  if (hay.includes('wp-content') || hay.includes('wp-includes')) add('WordPress', 'WordPress', 'PHP');
  if (hay.includes('cdn.shopify.com') || hay.includes('myshopify')) add('Shopify', 'Shopify', 'Ruby (Liquid)');
  if (hay.includes('wixstatic.com')) add('Wix', 'Wix', 'JavaScript (Velo)');
  if (hay.includes('static.squarespace.com')) add('Squarespace', 'Squarespace', 'JavaScript');
  if (hay.includes('sites/default/files') || hay.includes('drupal.settings')) add('Drupal', 'Drupal', 'PHP');
  if (hay.includes('joomla')) add('Joomla', 'Joomla', 'PHP');
  if (hay.includes('/_next/')) add('Next.js', 'Next.js', 'JavaScript/TypeScript (React, Node.js)');
  if (hay.includes('/_nuxt/')) add('Nuxt', 'Nuxt', 'JavaScript/TypeScript (Vue, Node.js)');
  if (hay.includes('/_astro/')) add('Astro', 'Astro', 'JavaScript');
  if (hay.includes('data-reactroot') || hay.includes('__reactrootcontainer') || hay.includes('react-dom'))
    add('React', 'React', 'JavaScript/TypeScript');
  if (hay.includes('ng-version')) add('Angular', 'Angular', 'TypeScript');
  if (document.querySelector('[data-v-app]') || hay.includes('__vue__') || /vue(\.runtime)?[.-]/.test(hay))
    add('Vue.js', 'Vue.js', 'JavaScript/TypeScript');
  if (hay.includes('jquery')) add('jQuery', 'jQuery', 'JavaScript');
  if (hay.includes('ember')) add('Ember.js', 'Ember.js', 'JavaScript/TypeScript');
  if (hay.includes('svelte') || hay.includes('_app') && hay.includes('svelte')) add('Svelte', 'Svelte', 'JavaScript/TypeScript');
  if (hay.includes('bootstrap')) add('Bootstrap', 'Bootstrap', 'CSS/JavaScript');
  if (hay.includes('tailwind')) add('Tailwind CSS', 'Tailwind CSS', 'CSS');
  if (hay.includes('laravel') || hay.includes('csrf-token') && hay.includes('_token')) add('Laravel', 'Laravel', 'PHP');

  const items = Array.from(findings.values());
  return {
    generator: generator || null,
    items,
    summary: items.length
      ? items.map(i => i.tech + ' → ' + i.lang).join('\n')
      : 'Tidak ada teknologi yang dikenali. Situs kemungkinan statis murni (HTML/CSS/JS) atau memakai setup yang jarang.'
  };
})();
