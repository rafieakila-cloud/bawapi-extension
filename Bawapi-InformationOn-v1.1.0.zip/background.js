// Information On — menyimpan header respons situs per tab untuk ditampilkan di popup
const serverInfo = {};

browser.webRequest.onHeadersReceived.addListener(
  details => {
    if (details.type !== 'main_frame' || !details.responseHeaders) return;
    const headers = {};
    for (const h of details.responseHeaders) headers[h.name.toLowerCase()] = h.value;
    serverInfo[details.tabId] = {
      server: headers['server'] || '',
      poweredBy: headers['x-powered-by'] || ''
    };
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

browser.tabs.onRemoved.addListener(tabId => { delete serverInfo[tabId]; });

browser.runtime.onMessage.addListener(msg => {
  if (msg && msg.type === 'info:get') {
    return Promise.resolve(serverInfo[msg.tabId] || null);
  }
  return undefined;
});
